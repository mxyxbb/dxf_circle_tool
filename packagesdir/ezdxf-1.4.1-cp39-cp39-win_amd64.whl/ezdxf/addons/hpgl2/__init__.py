#  Copyright (c) 2023, Manfred Moitzi
#  License: MIT License
#
# 1 plot unit (plu) = 0.025mm
# 40 plu = 1mm
# 1016 plu = 1 inch
# 3.39 plu = 1 dot @300 dpi
