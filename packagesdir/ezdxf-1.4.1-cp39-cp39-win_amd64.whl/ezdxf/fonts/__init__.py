#  Copyright (c) 2023, Manfred Moitzi
#  License: MIT License
