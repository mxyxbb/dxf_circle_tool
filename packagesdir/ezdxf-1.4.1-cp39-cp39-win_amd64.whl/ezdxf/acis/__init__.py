#  Copyright (c) 2022-2024, Manfred Moitzi
#  License: MIT License
# Users should always import from ezdxf.acis.api!
